import React, { useEffect, useState } from 'react';
import { Button, Card, Flex, Input } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import Back from "../assets/New Assets/Back.svg"
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const { Meta } = Card;

const FictionBooks = () => {
    const [books, setBooks] = useState([]);
    const [nextPage, setNextPage] = useState(null);
    const [searchValue, setSearchValue] = useState('');
    const Navigate = useNavigate();
    const handleScroll = () => {
        const scrollY = window.scrollY || document.documentElement.scrollTop;
        const windowHeight = window.innerHeight || document.documentElement.clientHeight;
        const documentHeight = document.documentElement.scrollHeight;

        // Load more books when the user has scrolled to the bottom of the page
        if (scrollY + windowHeight >= documentHeight - 200 && nextPage) {
            handleLoadMore();
        }
    };
    useEffect(() => {
        window.addEventListener('scroll', handleScroll);
        fetchData()
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, [nextPage]);
    console.log(books, "books>>>")
    const fetchData = async (nextPage) => {

        try {
            console.log(nextPage, "nextpage")
            const url = nextPage ? `http://skunkworks.ignitesol.com:8000/books/?page=${nextPage}` : 'http://skunkworks.ignitesol.com:8000/books/';
            const response = await axios.get(url);
            setBooks((prevBooks) => [...prevBooks, ...response.data.results]);
            const nextPageNumber = response.data.next ? new URL(response.data.next).searchParams.get('page') : null;
            setNextPage(nextPageNumber);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };
    const handleLoadMore = () => {
        if (nextPage) {
            fetchData(nextPage);
        }
    };

    const handleSearch = (value) => {
        console.log(value, "value>>>>")
        setSearchValue(value);
    };
    const handleClick = () => {
        Navigate("/")
    }

    const filterSearch = books.filter((book) =>
        book.title.toLowerCase().includes(searchValue.toLowerCase()) ||
        (book.authors && book.authors.some(author => author.name.toLowerCase().includes(searchValue.toLowerCase())))
    );

    const renderAuthors = (authors) => {

        return authors.map((author) => (
            <div key={author.name}>
                <div> {author.name}</div>
            </div>
        ));
    };
    const handleCard = (book) => {
        console.log(book, "id")
        if (book.formats['text/plain; charset=us-ascii']) {
            // console.log("yesss")
            window.location.href = `https://www.gutenberg.org/files/${book.id}/${book.id}-0.txt`;
        }
        else if (book.formats["text/html"]) {
            window.location.href = `https://www.gutenberg.org/ebooks/${book.id}.html.images`;
        }
        else if (book.formats["image/jpeg"]) {
            window.location.href = `https://www.gutenberg.org/cache/epub/${book.id}/pg${book.id}.cover.medium.jpg`;
        } else if (book.formats["application/epub+zip"]) {
            alert("No viewable version available")
        } else if (book.formats["application/octet-stream"]) {
            alert("No viewable version available")
        } else if (book.formats["application/rdf+xml"]) {
            alert("No viewable version available")
        } else if (book.formats["application/octet-stream"]) {
            alert("No viewable version available")
        }
        //         if (formats == "application/epub+zip") {
        //             alert("zip format is not valid")
        //         } else if (formats == text / plain
        // )

    }

    return (
        <div className='books-main-div' style={{ textAlign: "center" }}>
            <div className='books-div'>
                <button className='fiction-button' onClick={handleClick} style={{ border: "none", background: "none" }} >
                    <Flex gap="small" align="center" justify='space-between'>
                        <img className='image-button' src={Back} alt="Left Image" />
                        <span className='span-button' style={{ border: "none", cursor: "pointer" }}>
                            Fiction
                        </span>
                    </Flex>
                </button>
                <div>
                    <Input
                        type='search'
                        className='search-input'
                        placeholder='Search'
                        value={searchValue}
                        onChange={(e) => handleSearch(e.target.value)}
                        prefix={<SearchOutlined className="text-primary" />}
                    />
                </div>
            </div>
            <div className='card-container'>
                {filterSearch.length > 0 ? (
                    filterSearch.map((book, index) => (
                        <Card
                            onClick={() => handleCard(book)}
                            key={index}
                            className='cardbook '
                            cover={<img alt={book.title} src={book.formats["image/jpeg"]} />}
                        >
                            {/* {book?.map((res) => {
                            console.log(res, "data")
                        })} */}
                            {/* <Meta title={book.title} description={book.author} /> */}
                            <Meta title={book.title} description={renderAuthors(book.authors)} />
                        </Card>
                    ))
                ) : (
                    <div>No books found</div>
                )}

            </div>
            {/* {nextPage && (
                <button onClick={handleLoadMore} style={{ marginTop: '10px' }}>
                    Load More
                </button>
            )} */}
        </div>
    );
};

export default FictionBooks;
