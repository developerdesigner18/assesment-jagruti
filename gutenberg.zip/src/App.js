import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './component/LandingPage';
import FictionBook from './categoryBook/FictionBooks';
import FictionBooks from './categoryBook/FictionBooks';

const App = () => {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<LandingPage />} />
          <Route path='/fiction' element={<FictionBooks />} />
        </Routes>
      </BrowserRouter>

    </div>
  )
}

export default App
